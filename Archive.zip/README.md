# Digital_Filter_Design_WebApp
 a website that helps users to design a custom digital filter via zeros-poles placement on the z-plane.
